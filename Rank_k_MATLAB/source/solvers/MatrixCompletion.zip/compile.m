mex MinimizeSquaredDiffbudget.cpp
