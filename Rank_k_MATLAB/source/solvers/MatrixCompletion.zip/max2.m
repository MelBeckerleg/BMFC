function y=max2(x);
    y= max(x(:));
   